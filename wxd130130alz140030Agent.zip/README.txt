CTF AI

Group Members:
Wilson Ding
Andrew Zimmerman

To run:

javac -cp . ctf/agent/wxd130130alz140030Agent.java && java -cp . ctf.environment.TestPlaySurface